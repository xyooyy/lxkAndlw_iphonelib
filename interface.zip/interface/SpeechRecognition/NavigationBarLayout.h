//
//  MyNavigationBar.h
//  SpeechRecognition
//
//  Created by Lovells on 13-7-28.
//  Copyright (c) 2013年 Luwei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NavigationBarLayout : NSObject

- (id)initNavigationBar:(UINavigationBar *)navbar delegate:(id)delegate;

@end
