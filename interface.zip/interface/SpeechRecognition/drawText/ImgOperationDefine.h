//
//  ImgOperationDefine.h
//  ASTableViewCellShow
//
//  Created by  on 13-4-26.
//  Copyright (c) 2013年 Alpha Studio. All rights reserved.
//

#ifndef ASTableViewCellShow_ImgOperationDefine_h
#define ASTableViewCellShow_ImgOperationDefine_h

#define LINE_WIDTH        1.0
#define COLOR_ALPHA       1.0
#define CIRCLE_LEFT_UP_ANGLE   -0.5
#define CIRCLE_RIGHT_UP_ANGLE   0.5
#define CIRCLE_RIGHT_DOWN_ANGLE 0.5
#define CIRCLE_LEFT_DOWN_ANGLE  1.5

#endif
