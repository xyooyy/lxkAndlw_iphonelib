//
//  ImgTextConvDefine.h
//  ASTableViewCellShow
//
//  Created by  on 13-4-25.
//  Copyright (c) 2013年 Alpha Studio. All rights reserved.
//

#ifndef ASTableViewCellShow_ImgTextDefine_h
#define ASTableViewCellShow_ImgTextDefine_h

#define WORD_SIZE_CONVERSE  96.0 / 72.0
#define BIT_PER_COMPONENT   8

#endif
